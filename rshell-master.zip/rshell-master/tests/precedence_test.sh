#!/bin/sh
./bin/rshell < "tests/precedence_test.txt"

#tests for precedence operators
