#!/bin/sh
#tests for the test command
./bin/rshell < "tests/test_test.txt"





