#!/bin/sh
./bin/rshell < "tests/exit.txt"
